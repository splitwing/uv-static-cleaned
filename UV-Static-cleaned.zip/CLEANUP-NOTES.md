# UV-Static cleanup

Changes made:
- `index.html` is now the application frontend copied from `static/index.html`.
- The previous experimental root `index.html` was preserved as `index.experimental.html`.
- The UV configuration remains in `static/uv/uv.config.js` as the single configuration source.
- No change was made to the UV prefix or remote Bare server, because those settings require
  deployment-specific choices and should not be guessed.

This cleanup is intended to fix the frontend loading/order problem without changing the
proxy destination behavior.
